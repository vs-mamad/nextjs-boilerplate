import React from 'react';
import { Link } from 'react-router-dom';
import { Star, Play } from 'lucide-react';
import { motion } from 'framer-motion';

interface SeriesCardProps {
  id: number;
  title: string;
  persianTitle: string;
  posterUrl: string;
  startYear: number;
  endYear?: number;
  rating?: number;
  status?: string;
}

const SeriesCard: React.FC<SeriesCardProps> = ({ 
  id, 
  title, 
  persianTitle, 
  posterUrl, 
  startYear, 
  endYear, 
  rating,
  status 
}) => {
  return (
    <motion.div
      className="series-card"
      whileHover={{ y: -10 }}
      transition={{ duration: 0.3 }}
    >
      <Link to={`/series/${id}`}>
        <div className="relative overflow-hidden rounded-lg shadow-lg">
          <img 
            src={posterUrl} 
            alt={title} 
            className="w-full h-64 object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-100 transition-opacity duration-300" />
          
          {status === "Running" && (
            <div className="absolute top-2 right-2 bg-green-500 text-white text-xs px-2 py-1 rounded-full">
              در حال پخش
            </div>
          )}
          
          <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
            <h3 className="text-lg font-bold">{persianTitle}</h3>
            <p className="text-sm opacity-80">{title}</p>
            <div className="flex justify-between items-center mt-2">
              <span className="text-sm">
                {startYear}{endYear ? ` - ${endYear}` : ' - تاکنون'}
              </span>
              {rating && (
                <div className="flex items-center">
                  <Star className="w-4 h-4 text-yellow-400 ml-1" />
                  <span className="text-sm">{rating}</span>
                </div>
              )}
            </div>
            <motion.div 
              className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
              whileHover={{ scale: 1.1 }}
            >
              <div className="bg-primary/80 p-3 rounded-full">
                <Play className="w-8 h-8 text-white" />
              </div>
            </motion.div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
};

export default SeriesCard;