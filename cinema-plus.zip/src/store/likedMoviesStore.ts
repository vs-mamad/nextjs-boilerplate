import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Movie } from '../types';

interface LikedMoviesState {
  likedMovies: Movie[];
  toggleLikedMovie: (movie: Movie) => void;
  removeLikedMovie: (movieId: number) => void;
  clearLikedMovies: () => void;
}

export const useLikedMoviesStore = create<LikedMoviesState>()(
  persist(
    (set) => ({
      likedMovies: [],
      toggleLikedMovie: (movie) => 
        set((state) => {
          const isLiked = state.likedMovies.some(m => m.id === movie.id);
          if (isLiked) {
            return { 
              likedMovies: state.likedMovies.filter(m => m.id !== movie.id) 
            };
          } else {
            return { 
              likedMovies: [...state.likedMovies, movie] 
            };
          }
        }),
      removeLikedMovie: (movieId) => 
        set((state) => ({ 
          likedMovies: state.likedMovies.filter(movie => movie.id !== movieId) 
        })),
      clearLikedMovies: () => set({ likedMovies: [] }),
    }),
    {
      name: 'liked-movies-storage',
    }
  )
);