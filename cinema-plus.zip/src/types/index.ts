export interface Movie {
  id: number;
  title: string;
  persianTitle: string;
  posterUrl: string;
  backdropUrl: string;
  year: number;
  rating: number;
  duration: string;
  genres: string[];
  director: string;
  cast: string[];
  plot: string;
  trailerUrl?: string;
  downloadLinks: DownloadLink[];
  relatedMovies: RelatedMovie[];
  comments: Comment[];
}

export interface DownloadLink {
  id: number;
  quality: string;
  size: string;
  url: string;
}

export interface RelatedMovie {
  id: number;
  title: string;
  persianTitle: string;
  posterUrl: string;
  year: number;
}

export interface Comment {
  id: number;
  user: string;
  avatar: string;
  date: string;
  text: string;
  likes: number;
}

export interface WelcomeSlide {
  id: number;
  title: string;
  description: string;
  imageUrl: string;
}