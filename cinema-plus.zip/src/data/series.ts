import { Series } from '../types';

export const series: Series[] = [
  {
    id: 1,
    title: "Breaking Bad",
    persianTitle: "بریکینگ بد",
    posterUrl: "https://images.unsplash.com/photo-1504707748692-419802cf939d?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    backdropUrl: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    startYear: 2008,
    endYear: 2013,
    rating: 9.5,
    status: "Ended",
    genres: ["Crime", "Drama", "Thriller"],
    creator: "Vince Gilligan",
    cast: ["Bryan Cranston", "Aaron Paul", "Anna Gunn", "Dean Norris"],
    plot: "A high school chemistry teacher diagnosed with inoperable lung cancer turns to manufacturing and selling methamphetamine in order to secure his family's future.",
    trailerUrl: "https://www.youtube.com/watch?v=HhesaQXLuRY",
    seasons: [
      {
        id: 1,
        seasonNumber: 1,
        episodeCount: 7,
        year: 2008,
        episodes: [
          {
            id: 1,
            episodeNumber: 1,
            title: "Pilot",
            persianTitle: "قسمت اول",
            duration: "58m",
            plot: "A high school chemistry teacher is diagnosed with terminal lung cancer and turns to a life of crime.",
            downloadLinks: [
              { id: 1, quality: "1080p", size: "1.8GB", url: "#" },
              { id: 2, quality: "720p", size: "950MB", url: "#" },
              { id: 3, quality: "480p", size: "550MB", url: "#" }
            ]
          },
          {
            id: 2,
            episodeNumber: 2,
            title: "Cat's in the Bag...",
            persianTitle: "گربه در کیف است...",
            duration: "48m",
            plot: "Walt and Jesse attempt to dispose of the bodies of two rivals, but they're forced to deal with a new problem.",
            downloadLinks: [
              { id: 1, quality: "1080p", size: "1.7GB", url: "#" },
              { id: 2, quality: "720p", size: "900MB", url: "#" },
              { id: 3, quality: "480p", size: "520MB", url: "#" }
            ]
          },
          {
            id: 3,
            episodeNumber: 3,
            title: "...And the Bag's in the River",
            persianTitle: "...و کیف در رودخانه است",
            duration: "48m",
            plot: "Walt and Jesse clean up after the bathtub incident, and Walt is forced to tell Skyler he has cancer.",
            downloadLinks: [
              { id: 1, quality: "1080p", size: "1.7GB", url: "#" },
              { id: 2, quality: "720p", size: "900MB", url: "#" },
              { id: 3, quality: "480p", size: "520MB", url: "#" }
            ]
          }
        ]
      },
      {
        id: 2,
        seasonNumber: 2,
        episodeCount: 13,
        year: 2009,
        episodes: [
          {
            id: 1,
            episodeNumber: 1,
            title: "Seven Thirty-Seven",
            persianTitle: "هفت سی و هفت",
            duration: "47m",
            plot: "Walt and Jesse realize how dire their situation is. They must come up with a plan to kill Tuco before Tuco kills them first.",
            downloadLinks: [
              { id: 1, quality: "1080p", size: "1.7GB", url: "#" },
              { id: 2, quality: "720p", size: "900MB", url: "#" },
              { id: 3, quality: "480p", size: "520MB", url: "#" }
            ]
          },
          {
            id: 2,
            episodeNumber: 2,
            title: "Grilled",
            persianTitle: "کباب شده",
            duration: "48m",
            plot: "Walt and Jesse find themselves trapped with Tuco. Meanwhile, the DEA believes they have a line on the mysterious Heisenberg.",
            downloadLinks: [
              { id: 1, quality: "1080p", size: "1.7GB", url: "#" },
              { id: 2, quality: "720p", size: "900MB", url: "#" },
              { id: 3, quality: "480p", size: "520MB", url: "#" }
            ]
          }
        ]
      }
    ],
    relatedSeries: [
      { id: 2, title: "Better Call Saul", persianTitle: "بهتره با ساول تماس بگیری", posterUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", startYear: 2015, endYear: 2022 },
      { id: 3, title: "Ozark", persianTitle: "اوزارک", posterUrl: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", startYear: 2017, endYear: 2022 },
      { id: 4, title: "Narcos", persianTitle: "نارکوس", posterUrl: "https://images.unsplash.com/photo-1517404215738-15263e9f9178?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", startYear: 2015, endYear: 2017 }
    ],
    comments: [
      { id: 1, user: "محمد رضایی", avatar: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "3 روز پیش", text: "یکی از بهترین سریال‌های تاریخ تلویزیون. بازی برایان کرنستون فوق‌العاده است.", likes: 48 },
      { id: 2, user: "سارا محمدی", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "1 هفته پیش", text: "داستان‌پردازی عالی و شخصیت‌های پیچیده. هر فصل بهتر از فصل قبل می‌شود.", likes: 36 }
    ]
  },
  {
    id: 2,
    title: "Game of Thrones",
    persianTitle: "بازی تاج و تخت",
    posterUrl: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    backdropUrl: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    startYear: 2011,
    endYear: 2019,
    rating: 9.2,
    status: "Ended",
    genres: ["Action", "Adventure", "Drama", "Fantasy"],
    creator: "David Benioff, D.B. Weiss",
    cast: ["Emilia Clarke", "Kit Harington", "Peter Dinklage", "Lena Headey"],
    plot: "Nine noble families fight for control over the lands of Westeros, while an ancient enemy returns after being dormant for millennia.",
    trailerUrl: "https://www.youtube.com/watch?v=KPLWWIOCOOQ",
    seasons: [
      {
        id: 1,
        seasonNumber: 1,
        episodeCount: 10,
        year: 2011,
        episodes: [
          {
            id: 1,
            episodeNumber: 1,
            title: "Winter Is Coming",
            persianTitle: "زمستان در راه است",
            duration: "62m",
            plot: "Eddard Stark is torn between his family and an old friend when asked to serve at the side of King Robert Baratheon.",
            downloadLinks: [
              { id: 1, quality: "1080p", size: "2.1GB", url: "#" },
              { id: 2, quality: "720p", size: "1.2GB", url: "#" },
              { id: 3, quality: "480p", size: "650MB", url: "#" }
            ]
          },
          {
            id: 2,
            episodeNumber: 2,
            title: "The Kingsroad",
            persianTitle: "جاده پادشاهی",
            duration: "56m",
            plot: "While Bran recovers from his fall, Ned takes only his daughters to King's Landing.",
            downloadLinks: [
              { id: 1, quality: "1080p", size: "2.0GB", url: "#" },
              { id: 2, quality: "720p", size: "1.1GB", url: "#" },
              { id: 3, quality: "480p", size: "600MB", url: "#" }
            ]
          }
        ]
      },
      {
        id: 2,
        seasonNumber: 2,
        episodeCount: 10,
        year: 2012,
        episodes: [
          {
            id: 1,
            episodeNumber: 1,
            title: "The North Remembers",
            persianTitle: "شمال به یاد دارد",
            duration: "53m",
            plot: "As Robb Stark and his northern army continue the war against the Lannisters, Tyrion arrives in King's Landing to counsel Joffrey.",
            downloadLinks: [
              { id: 1, quality: "1080p", size: "2.0GB", url: "#" },
              { id: 2, quality: "720p", size: "1.1GB", url: "#" },
              { id: 3, quality: "480p", size: "600MB", url: "#" }
            ]
          }
        ]
      }
    ],
    relatedSeries: [
      { id: 5, title: "House of the Dragon", persianTitle: "خاندان اژدها", posterUrl: "https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", startYear: 2022 },
      { id: 6, title: "The Witcher", persianTitle: "ویچر", posterUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", startYear: 2019 },
      { id: 7, title: "The Last Kingdom", persianTitle: "آخرین پادشاهی", posterUrl: "https://images.unsplash.com/photo-1579156412503-f22426588c6d?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", startYear: 2015, endYear: 2022 }
    ],
    comments: [
      { id: 1, user: "علی حسینی", avatar: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "2 روز پیش", text: "فصل‌های اول تا ششم فوق‌العاده بودند. جلوه‌های ویژه و داستان عالی.", likes: 52 },
      { id: 2, user: "مریم کریمی", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "5 روز پیش", text: "یکی از بهترین سریال‌های فانتزی. شخصیت‌پردازی عالی و داستان پیچیده.", likes: 41 }
    ]
  },
  {
    id: 3,
    title: "Stranger Things",
    persianTitle: "چیزهای عجیب",
    posterUrl: "https://images.unsplash.com/photo-1534809027769-b00d750a6bac?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    backdropUrl: "https://images.unsplash.com/photo-1478720568477-152d9b164e26?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    startYear: 2016,
    rating: 8.7,
    status: "Running",
    genres: ["Drama", "Fantasy", "Horror", "Sci-Fi"],
    creator: "The Duffer Brothers",
    cast: ["Millie Bobby Brown", "Finn Wolfhard", "Winona Ryder", "David Harbour"],
    plot: "When a young boy disappears, his mother, a police chief, and his friends must confront terrifying supernatural forces in order to get him back.",
    trailerUrl: "https://www.youtube.com/watch?v=b9EkMc79ZSU",
    seasons: [
      {
        id: 1,
        seasonNumber: 1,
        episodeCount: 8,
        year: 2016,
        episodes: [
          {
            id: 1,
            episodeNumber: 1,
            title: "Chapter One: The Vanishing of Will Byers",
            persianTitle: "فصل اول: ناپدید شدن ویل بایرز",
            duration: "47m",
            plot: "On his way home from a friend's house, young Will sees something terrifying. Nearby, a sinister secret lurks in the depths of a government lab.",
            downloadLinks: [
              { id: 1, quality: "1080p", size: "1.8GB", url: "#" },
              { id: 2, quality: "720p", size: "950MB", url: "#" },
              { id: 3, quality: "480p", size: "550MB", url: "#" }
            ]
          },
          {
            id: 2,
            episodeNumber: 2,
            title: "Chapter Two: The Weirdo on Maple Street",
            persianTitle: "فصل دوم: عجیب و غریب در خیابان میپل",
            duration: "55m",
            plot: "Lucas, Mike and Dustin try to talk to the girl they found in the woods. Hopper questions an anxious Joyce about an unsettling phone call.",
            downloadLinks: [
              { id: 1, quality: "1080p", size: "1.9GB", url: "#" },
              { id: 2, quality: "720p", size: "980MB", url: "#" },
              { id: 3, quality: "480p", size: "570MB", url: "#" }
            ]
          }
        ]
      },
      {
        id: 2,
        seasonNumber: 2,
        episodeCount: 9,
        year: 2017,
        episodes: [
          {
            id: 1,
            episodeNumber: 1,
            title: "Chapter One: MADMAX",
            persianTitle: "فصل اول: مدمکس",
            duration: "48m",
            plot: "As the town preps for Halloween, a high-scoring rival shakes things up at the arcade, and a skeptical Hopper inspects a field of rotting pumpkins.",
            downloadLinks: [
              { id: 1, quality: "1080p", size: "1.8GB", url: "#" },
              { id: 2, quality: "720p", size: "950MB", url: "#" },
              { id: 3, quality: "480p", size: "550MB", url: "#" }
            ]
          }
        ]
      }
    ],
    relatedSeries: [
      { id: 8, title: "Dark", persianTitle: "تاریک", posterUrl: "https://images.unsplash.com/photo-1572883454114-1cf0031ede2a?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", startYear: 2017, endYear: 2020 },
      { id: 9, title: "The OA", persianTitle: "او‌ای", posterUrl: "https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", startYear: 2016, endYear: 2019 },
      { id: 10, title: "Black Mirror", persianTitle: "آینه سیاه", posterUrl: "https://images.unsplash.com/photo-1516339901601-2e1b62dc0c45?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", startYear: 2011 }
    ],
    comments: [
      { id: 1, user: "امیر محمدی", avatar: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "1 هفته پیش", text: "فضاسازی دهه ۸۰ میلادی عالی است. بازی بچه‌ها فوق‌العاده است.", likes: 38 },
      { id: 2, user: "نیلوفر احمدی", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "2 هفته پیش", text: "ترکیب ژانر وحشت و علمی تخیلی عالی است. موسیقی متن هم فوق‌العاده است.", likes: 29 }
    ]
  },
  {
    id: 4,
    title: "The Crown",
    persianTitle: "تاج",
    posterUrl: "https://images.unsplash.com/photo-1589656966895-2f33e7653819?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    backdropUrl: "https://images.unsplash.com/photo-1569587112025-0d160c8c6f6f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    startYear: 2016,
    endYear: 2023,
    rating: 8.7,
    status: "Ended",
    genres: ["Biography", "Drama", "History"],
    creator: "Peter Morgan",
    cast: ["Claire Foy", "Olivia Colman", "Imelda Staunton", "Matt Smith"],
    plot: "Follows the political rivalries and romance of Queen Elizabeth II's reign and the events that shaped the second half of the twentieth century.",
    trailerUrl: "https://www.youtube.com/watch?v=JWtnJjn6ng0",
    seasons: [
      {
        id: 1,
        seasonNumber: 1,
        episodeCount: 10,
        year: 2016,
        episodes: [
          {
            id: 1,
            episodeNumber: 1,
            title: "Wolferton Splash",
            persianTitle: "اسپلش ولفرتون",
            duration: "57m",
            plot: "A young Princess Elizabeth marries Prince Philip. As King George VI's health worsens, Winston Churchill is elected prime minister for the second time.",
            downloadLinks: [
              { id: 1, quality: "1080p", size: "2.0GB", url: "#" },
              { id: 2, quality: "720p", size: "1.1GB", url: "#" },
              { id: 3, quality: "480p", size: "600MB", url: "#" }
            ]
          },
          {
            id: 2,
            episodeNumber: 2,
            title: "Hyde Park Corner",
            persianTitle: "گوشه هاید پارک",
            duration: "61m",
            plot: "With King George too ill to travel, Elizabeth and Philip embark on a four-continent Commonwealth tour. Party leaders attempt to undermine Churchill.",
            downloadLinks: [
              { id: 1, quality: "1080p", size: "2.1GB", url: "#" },
              { id: 2, quality: "720p", size: "1.2GB", url: "#" },
              { id: 3, quality: "480p", size: "650MB", url: "#" }
            ]
          }
        ]
      }
    ],
    relatedSeries: [
      { id: 11, title: "Downton Abbey", persianTitle: "دانتون ابی", posterUrl: "https://images.unsplash.com/photo-1572883454114-1cf0031ede2a?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", startYear: 2010, endYear: 2015 },
      { id: 12, title: "Victoria", persianTitle: "ویکتوریا", posterUrl: "https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", startYear: 2016, endYear: 2019 },
      { id: 13, title: "The Queen's Gambit", persianTitle: "گامبی وزیر", posterUrl: "https://images.unsplash.com/photo-1579156412503-f22426588c6d?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", startYear: 2020, endYear: 2020 }
    ],
    comments: [
      { id: 1, user: "سعید کریمی", avatar: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "3 روز پیش", text: "بازسازی تاریخی فوق‌العاده و بازی‌های درخشان. طراحی صحنه و لباس عالی است.", likes: 42 },
      { id: 2, user: "فاطمه رضایی", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "1 هفته پیش", text: "روایت جذابی از زندگی ملکه الیزابت دوم. فیلمنامه قوی و کارگردانی عالی.", likes: 35 }
    ]
  }
];