import { Movie, WelcomeSlide } from '../types';

export const movies: Movie[] = [
  {
    id: 1,
    title: "Inception",
    persianTitle: "تلقین",
    posterUrl: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    backdropUrl: "https://images.unsplash.com/photo-1478720568477-152d9b164e26?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    year: 2010,
    rating: 8.8,
    duration: "2h 28m",
    genres: ["Action", "Adventure", "Sci-Fi"],
    director: "Christopher Nolan",
    cast: ["Leonardo DiCaprio", "Joseph Gordon-Levitt", "Ellen Page"],
    plot: "A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.",
    trailerUrl: "https://www.youtube.com/watch?v=YoHD9XEInc0",
    downloadLinks: [
      { id: 1, quality: "1080p", size: "2.3GB", url: "#" },
      { id: 2, quality: "720p", size: "1.1GB", url: "#" },
      { id: 3, quality: "480p", size: "700MB", url: "#" }
    ],
    relatedMovies: [
      { id: 2, title: "Interstellar", persianTitle: "میان ستاره‌ای", posterUrl: "https://images.unsplash.com/photo-1506268919522-a927511962a9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2014 },
      { id: 3, title: "The Dark Knight", persianTitle: "شوالیه تاریکی", posterUrl: "https://images.unsplash.com/photo-1531259683007-016a7b628fc3?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2008 },
      { id: 4, title: "Tenet", persianTitle: "تنت", posterUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2020 },
      { id: 5, title: "Dunkirk", persianTitle: "دانکرک", posterUrl: "https://images.unsplash.com/photo-1547700055-b61cacebece9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2017 }
    ],
    comments: [
      { id: 1, user: "علی رضایی", avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "2 روز پیش", text: "یکی از بهترین فیلم‌های کریستوفر نولان. داستان پیچیده و جذابی داره.", likes: 24 },
      { id: 2, user: "مریم حسینی", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "1 هفته پیش", text: "بازی لئوناردو دی‌کاپریو فوق‌العاده بود. موسیقی متن هم عالی بود.", likes: 18 }
    ]
  },
  {
    id: 2,
    title: "Interstellar",
    persianTitle: "میان ستاره‌ای",
    posterUrl: "https://images.unsplash.com/photo-1506268919522-a927511962a9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    backdropUrl: "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    year: 2014,
    rating: 8.6,
    duration: "2h 49m",
    genres: ["Adventure", "Drama", "Sci-Fi"],
    director: "Christopher Nolan",
    cast: ["Matthew McConaughey", "Anne Hathaway", "Jessica Chastain"],
    plot: "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.",
    trailerUrl: "https://www.youtube.com/watch?v=zSWdZVtXT7E",
    downloadLinks: [
      { id: 1, quality: "1080p", size: "2.8GB", url: "#" },
      { id: 2, quality: "720p", size: "1.4GB", url: "#" },
      { id: 3, quality: "480p", size: "800MB", url: "#" }
    ],
    relatedMovies: [
      { id: 1, title: "Inception", persianTitle: "تلقین", posterUrl: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2010 },
      { id: 3, title: "The Dark Knight", persianTitle: "شوالیه تاریکی", posterUrl: "https://images.unsplash.com/photo-1531259683007-016a7b628fc3?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2008 },
      { id: 4, title: "Tenet", persianTitle: "تنت", posterUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2020 },
      { id: 5, title: "Dunkirk", persianTitle: "دانکرک", posterUrl: "https://images.unsplash.com/photo-1547700055-b61cacebece9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2017 }
    ],
    comments: [
      { id: 1, user: "محمد کریمی", avatar: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "3 روز پیش", text: "فیلم فوق‌العاده‌ای بود. جلوه‌های ویژه و داستان عالی.", likes: 32 },
      { id: 2, user: "سارا احمدی", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "2 هفته پیش", text: "یکی از بهترین فیلم‌های علمی تخیلی که دیدم. موسیقی متن هانس زیمر فوق‌العاده بود.", likes: 27 }
    ]
  },
  {
    id: 3,
    title: "The Dark Knight",
    persianTitle: "شوالیه تاریکی",
    posterUrl: "https://images.unsplash.com/photo-1531259683007-016a7b628fc3?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    backdropUrl: "https://images.unsplash.com/photo-1513106580091-1d82408b8cd6?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    year: 2008,
    rating: 9.0,
    duration: "2h 32m",
    genres: ["Action", "Crime", "Drama"],
    director: "Christopher Nolan",
    cast: ["Christian Bale", "Heath Ledger", "Aaron Eckhart"],
    plot: "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice.",
    trailerUrl: "https://www.youtube.com/watch?v=EXeTwQWrcwY",
    downloadLinks: [
      { id: 1, quality: "1080p", size: "2.5GB", url: "#" },
      { id: 2, quality: "720p", size: "1.2GB", url: "#" },
      { id: 3, quality: "480p", size: "750MB", url: "#" }
    ],
    relatedMovies: [
      { id: 1, title: "Inception", persianTitle: "تلقین", posterUrl: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2010 },
      { id: 2, title: "Interstellar", persianTitle: "میان ستاره‌ای", posterUrl: "https://images.unsplash.com/photo-1506268919522-a927511962a9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2014 },
      { id: 4, title: "Tenet", persianTitle: "تنت", posterUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2020 },
      { id: 5, title: "Dunkirk", persianTitle: "دانکرک", posterUrl: "https://images.unsplash.com/photo-1547700055-b61cacebece9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2017 }
    ],
    comments: [
      { id: 1, user: "رضا محمدی", avatar: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "1 روز پیش", text: "بازی هیث لجر در نقش جوکر فوق‌العاده بود. یکی از بهترین فیلم‌های ابرقهرمانی تاریخ سینما.", likes: 45 },
      { id: 2, user: "نیلوفر کاظمی", avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "5 روز پیش", text: "فیلمنامه قوی و کارگردانی عالی. بهترین فیلم سه‌گانه بتمن نولان.", likes: 36 }
    ]
  },
  {
    id: 4,
    title: "Tenet",
    persianTitle: "تنت",
    posterUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    backdropUrl: "https://images.unsplash.com/photo-1518331647614-7a1f04cd34cf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    year: 2020,
    rating: 7.5,
    duration: "2h 30m",
    genres: ["Action", "Sci-Fi", "Thriller"],
    director: "Christopher Nolan",
    cast: ["John David Washington", "Robert Pattinson", "Elizabeth Debicki"],
    plot: "Armed with only one word, Tenet, and fighting for the survival of the entire world, a Protagonist journeys through a twilight world of international espionage on a mission that will unfold in something beyond real time.",
    trailerUrl: "https://www.youtube.com/watch?v=LdOM0x0XDMo",
    downloadLinks: [
      { id: 1, quality: "1080p", size: "2.6GB", url: "#" },
      { id: 2, quality: "720p", size: "1.3GB", url: "#" },
      { id: 3, quality: "480p", size: "780MB", url: "#" }
    ],
    relatedMovies: [
      { id: 1, title: "Inception", persianTitle: "تلقین", posterUrl: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2010 },
      { id: 2, title: "Interstellar", persianTitle: "میان ستاره‌ای", posterUrl: "https://images.unsplash.com/photo-1506268919522-a927511962a9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2014 },
      { id: 3, title: "The Dark Knight", persianTitle: "شوالیه تاریکی", posterUrl: "https://images.unsplash.com/photo-1531259683007-016a7b628fc3?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2008 },
      { id: 5, title: "Dunkirk", persianTitle: "دانکرک", posterUrl: "https://images.unsplash.com/photo-1547700055-b61cacebece9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2017 }
    ],
    comments: [
      { id: 1, user: "امیر حسینی", avatar: "https://images.unsplash.com/photo-1564564321837-a57b7070ac4f?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "4 روز پیش", text: "فیلم پیچیده‌ای بود اما جذاب. باید چند بار ببینی تا کامل متوجه بشی.", likes: 19 },
      { id: 2, user: "فاطمه رضایی", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "1 هفته پیش", text: "جلوه‌های ویژه و صحنه‌های اکشن فوق‌العاده بود. موسیقی متن هم عالی بود.", likes: 15 }
    ]
  },
  {
    id: 5,
    title: "Dunkirk",
    persianTitle: "دانکرک",
    posterUrl: "https://images.unsplash.com/photo-1547700055-b61cacebece9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    backdropUrl: "https://images.unsplash.com/photo-1468276311594-df7cb65d8df6?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    year: 2017,
    rating: 7.9,
    duration: "1h 46m",
    genres: ["Action", "Drama", "History"],
    director: "Christopher Nolan",
    cast: ["Fionn Whitehead", "Tom Hardy", "Mark Rylance"],
    plot: "Allied soldiers from Belgium, the British Commonwealth and Empire, and France are surrounded by the German Army and evacuated during a fierce battle in World War II.",
    trailerUrl: "https://www.youtube.com/watch?v=F-eMt3SrfFU",
    downloadLinks: [
      { id: 1, quality: "1080p", size: "2.1GB", url: "#" },
      { id: 2, quality: "720p", size: "1.0GB", url: "#" },
      { id: 3, quality: "480p", size: "650MB", url: "#" }
    ],
    relatedMovies: [
      { id: 1, title: "Inception", persianTitle: "تلقین", posterUrl: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2010 },
      { id: 2, title: "Interstellar", persianTitle: "میان ستاره‌ای", posterUrl: "https://images.unsplash.com/photo-1506268919522-a927511962a9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2014 },
      { id: 3, title: "The Dark Knight", persianTitle: "شوالیه تاریکی", posterUrl: "https://images.unsplash.com/photo-1531259683007-016a7b628fc3?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2008 },
      { id: 4, title: "Tenet", persianTitle: "تنت", posterUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 2020 }
    ],
    comments: [
      { id: 1, user: "حسین علوی", avatar: "https://images.unsplash.com/photo-1542178243-bc20204b769f?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "2 روز پیش", text: "فیلم جنگی فوق‌العاده‌ای بود. کارگردانی نولان عالی بود.", likes: 28 },
      { id: 2, user: "زهرا محمدی", avatar: "https://images.unsplash.com/photo-1554151228-14d9def656e4?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "4 روز پیش", text: "موسیقی متن هانس زیمر و فیلمبرداری فوق‌العاده بود. یکی از بهترین فیلم‌های جنگی سال‌های اخیر.", likes: 22 }
    ]
  },
  {
    id: 6,
    title: "The Shawshank Redemption",
    persianTitle: "رستگاری در شاوشنک",
    posterUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    backdropUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    year: 1994,
    rating: 9.3,
    duration: "2h 22m",
    genres: ["Drama"],
    director: "Frank Darabont",
    cast: ["Tim Robbins", "Morgan Freeman", "Bob Gunton"],
    plot: "Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.",
    trailerUrl: "https://www.youtube.com/watch?v=6hB3S9bIaco",
    downloadLinks: [
      { id: 1, quality: "1080p", size: "2.4GB", url: "#" },
      { id: 2, quality: "720p", size: "1.2GB", url: "#" },
      { id: 3, quality: "480p", size: "700MB", url: "#" }
    ],
    relatedMovies: [
      { id: 7, title: "The Godfather", persianTitle: "پدرخوانده", posterUrl: "https://images.unsplash.com/photo-1601513237233-d3c489dffc11?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 1972 },
      { id: 8, title: "Pulp Fiction", persianTitle: "داستان عامه‌پسند", posterUrl: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 1994 },
      { id: 9, title: "Fight Club", persianTitle: "باشگاه مشت‌زنی", posterUrl: "https://images.unsplash.com/photo-1579702493440-8b1b56d47e03?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 1999 },
      { id: 10, title: "Forrest Gump", persianTitle: "فارست گامپ", posterUrl: "https://images.unsplash.com/photo-1580130732478-4e339fb6836f?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", year: 1994 }
    ],
    comments: [
      { id: 1, user: "علی محمدی", avatar: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "3 روز پیش", text: "بهترین فیلم تاریخ سینما. داستان فوق‌العاده و بازی‌های درخشان.", likes: 56 },
      { id: 2, user: "مریم احمدی", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80", date: "1 هفته پیش", text: "فیلمی که هر بار می‌بینم لذت می‌برم. پایان فیلم فوق‌العاده است.", likes: 42 }
    ]
  }
];

export const welcomeSlides: WelcomeSlide[] = [
  {
    id: 1,
    title: "به سینما پلاس خوش آمدید",
    description: "بهترین فیلم‌های جهان را با کیفیت عالی تماشا کنید",
    imageUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80"
  },
  {
    id: 2,
    title: "دانلود فیلم‌ها با کیفیت‌های مختلف",
    description: "فیلم‌های مورد علاقه خود را با کیفیت‌های مختلف دانلود کنید",
    imageUrl: "https://images.unsplash.com/photo-1485846234645-a62644f84728?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80"
  },
  {
    id: 3,
    title: "نظرات و امتیازدهی",
    description: "نظرات خود را به اشتراک بگذارید و به فیلم‌ها امتیاز دهید",
    imageUrl: "https://images.unsplash.com/photo-1512070679279-8988d32161be?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80"
  }
];