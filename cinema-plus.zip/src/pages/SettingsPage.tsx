import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Moon, Sun, Info, Heart } from 'lucide-react';
import { useThemeStore } from '../store/themeStore';
import { Link } from 'react-router-dom';

const SettingsPage: React.FC = () => {
  const { isDarkMode, toggleTheme } = useThemeStore();
  const [isClicked, setIsClicked] = useState(false);

  const handleThemeChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedTheme = event.target.value;
    if ((selectedTheme === 'dark' && !isDarkMode) || (selectedTheme === 'light' && isDarkMode)) {
      toggleTheme();
    }
  };

  const handleDonateClick = () => {
    setIsClicked(true);
    setTimeout(() => setIsClicked(false), 300);
  };

  return (
    <div className="pt-20 pb-24 md:pb-10 px-4 md:px-8">
      <div className="container mx-auto max-w-2xl">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-2xl md:text-3xl font-bold mb-6">تنظیمات</h1>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="card p-6 mb-6"
        >
          <h2 className="text-xl font-bold mb-4 flex items-center">
            {isDarkMode ? (
              <Moon className="w-5 h-5 ml-2 text-primary" />
            ) : (
              <Sun className="w-5 h-5 ml-2 text-primary" />
            )}
            تم برنامه
          </h2>
          <div className="flex items-center justify-between">
            <span>انتخاب تم</span>
            <select
              value={isDarkMode ? 'dark' : 'light'}
              onChange={handleThemeChange}
              className="border rounded-lg px-4 py-2 focus:ring-primary focus:outline-none dark:bg-slate-600"
            >
              <option value="light">روشن</option>
              <option value="dark">تاریک</option>
            </select>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="card p-6"
        >
          <h2 className="text-xl font-bold mb-4 flex items-center">
            <Info className="w-5 h-5 ml-2 text-primary" />
            درباره ما
          </h2>
          <p className="mb-4">
            سینما پلاس یک پلتفرم آنلاین برای دسترسی به فیلم‌های روز دنیا با کیفیت‌های مختلف است. هدف ما فراهم کردن تجربه‌ای لذت‌بخش برای علاقه‌مندان به سینما است.
          </p>
          <p className="mb-4">
            لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است.
          </p>
        </motion.div>

        <Link to="https://google.com">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }} className="flex justify-center mt-6">
            <motion.button
              onClick={handleDonateClick}
              whileTap={{ scale: 0.9 }}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg text-white font-bold transition-all ${isClicked ? 'bg-red-700' : 'bg-red-600'} shadow-lg hover:bg-red-700 focus:outline-none`}
            >
              <Heart className="w-5 h-5" /> حمایت از ما
            </motion.button>
          </motion.div>
        </Link>
      </div>
    </div>
  );
};

export default SettingsPage;