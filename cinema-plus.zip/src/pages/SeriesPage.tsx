import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, Download, Copy, Star, Clock, Calendar, Tv, User, MessageSquare, Heart, ChevronDown, ChevronUp } from 'lucide-react';
import { series } from '../data/series';
import { Series, Episode } from '../types';
import { useLikedMoviesStore } from '../store/likedMoviesStore';

const SeriesPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [seriesData, setSeriesData] = useState<Series | null>(null);
  const [copied, setCopied] = useState<number | null>(null);
  const [expandedSeasons, setExpandedSeasons] = useState<number[]>([]);
  const { likedMovies, toggleLikedMovie } = useLikedMoviesStore();

  useEffect(() => {
    window.scrollTo(0, 0);
    if (id) {
      const foundSeries = series.find(s => s.id === parseInt(id));
      if (foundSeries) {
        setSeriesData(foundSeries);
        // Expand the first season by default
        if (foundSeries.seasons.length > 0) {
          setExpandedSeasons([foundSeries.seasons[0].id]);
        }
      }
    }
  }, [id]);

  const copyToClipboard = (url: string, linkId: number) => {
    navigator.clipboard.writeText(url);
    setCopied(linkId);
    setTimeout(() => setCopied(null), 2000);
  };

  const toggleSeason = (seasonId: number) => {
    setExpandedSeasons(prev => 
      prev.includes(seasonId)
        ? prev.filter(id => id !== seasonId)
        : [...prev, seasonId]
    );
  };

  if (!seriesData) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  const isLiked = likedMovies.some(m => m.id === seriesData.id);

  return (
    <div className="pb-24 md:pb-10">
      {/* Hero Section */}
      <div 
        className="relative h-[70vh] bg-cover bg-center"
        style={{ 
          backgroundImage: `linear-gradient(to bottom, rgba(0,0,0,0.7), rgba(0,0,0,0.9)), url(${seriesData.backdropUrl})` 
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/70 to-transparent"></div>
        <div className="container mx-auto px-4 h-full flex items-end pb-10 relative z-10">
          <div className="flex flex-col md:flex-row items-end md:items-end gap-6 text-white w-full">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="w-32 md:w-48 flex-shrink-0 relative group self-center md:self-auto mr-auto ml-auto md:mr-0"
            >
              <div className="relative overflow-hidden rounded-lg shadow-2xl">
                <img 
                  src={seriesData.posterUrl} 
                  alt={seriesData.title} 
                  className="w-full h-auto rounded-lg shadow-lg border-2 border-white/10 transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={() => toggleLikedMovie(seriesData)}
                className="absolute top-2 right-2 p-2 bg-black/50 rounded-full text-white hover:bg-primary transition-colors duration-300"
              >
                <Heart className={`w-5 h-5 ${isLiked ? 'fill-primary text-primary' : 'text-white'}`} />
              </motion.button>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="flex-1 text-center md:text-right"
            >
              <h1 className="text-2xl md:text-4xl font-bold mb-2 text-white drop-shadow-md">{seriesData.persianTitle}</h1>
              <h2 className="text-lg md:text-xl text-gray-200 mb-4 drop-shadow-md">{seriesData.title}</h2>
              
              <div className="flex flex-wrap gap-3 mb-4 justify-center md:justify-start">
                {seriesData.genres.map((genre, index) => (
                  <span 
                    key={index} 
                    className="px-3 py-1 bg-primary/90 text-white rounded-full text-sm font-medium shadow-md"
                  >
                    {genre}
                  </span>
                ))}
              </div>
              
              <div className="flex flex-wrap gap-4 text-sm md:text-base mb-6 text-white justify-center md:justify-start">
                <div className="flex items-center bg-black/50 px-3 py-1 rounded-full shadow-md">
                  <Star className="w-4 h-4 text-yellow-400 ml-1" />
                  <span>{seriesData.rating}/10</span>
                </div>
                <div className="flex items-center bg-black/50 px-3 py-1 rounded-full shadow-md">
                  <Calendar className="w-4 h-4 text-gray-300 ml-1" />
                  <span>
                    {seriesData.startYear}
                    {seriesData.endYear ? ` - ${seriesData.endYear}` : ' - تاکنون'}
                  </span>
                </div>
                <div className="flex items-center bg-black/50 px-3 py-1 rounded-full shadow-md">
                  <span className={`w-2 h-2 rounded-full ml-1 ${
                    seriesData.status === 'Running' ? 'bg-green-500' : 'bg-red-500'
                  }`}></span>
                  <span>
                    {seriesData.status === 'Running' ? 'در حال پخش' : 'پایان یافته'}
                  </span>
                </div>
              </div>
              
              <div className="flex gap-3 justify-center md:justify-start">
                <motion.a
                  href={seriesData.trailerUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="btn-primary flex items-center shadow-lg"
                >
                  <Play className="w-4 h-4 ml-2" />
                  پخش تریلر
                </motion.a>
                <motion.a
                  href="#seasons"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-md flex items-center transition-colors shadow-lg"
                >
                  <Download className="w-4 h-4 ml-2" />
                  دانلود قسمت‌ها
                </motion.a>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Content Section */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="card p-6 mb-8"
            >
              <h2 className="text-xl font-bold mb-4 flex items-center">
                <Tv className="w-5 h-5 ml-2 text-primary" />
                خلاصه داستان
              </h2>
              <p className="leading-relaxed">{seriesData.plot}</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="card p-6 mb-8"
            >
              <h2 className="text-xl font-bold mb-4 flex items-center">
                <User className="w-5 h-5 ml-2 text-primary" />
                عوامل سریال
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="font-semibold text-gray-500 dark:text-gray-400 mb-1">سازنده</h3>
                  <p>{seriesData.creator}</p>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-500 dark:text-gray-400 mb-1">بازیگران</h3>
                  <p>{seriesData.cast.join('، ')}</p>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              id="seasons"
              className="card p-6 mb-8"
            >
              <h2 className="text-xl font-bold mb-6 flex items-center">
                <Download className="w-5 h-5 ml-2 text-primary" />
                فصل‌ها و قسمت‌ها
              </h2>
              
              <div className="space-y-4">
                {seriesData.seasons.map((season) => (
                  <div key={season.id} className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
                    <button
                      onClick={() => toggleSeason(season.id)}
                      className="w-full flex justify-between items-center p-4 bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                    >
                      <div className="flex items-center">
                        <span className="font-semibold">فصل {season.seasonNumber}</span>
                        <span className="text-gray-500 dark:text-gray-400 mr-2">
                          ({season.year} • {season.episodeCount} قسمت)
                        </span>
                      </div>
                      {expandedSeasons.includes(season.id) ? (
                        <ChevronUp className="w-5 h-5" />
                      ) : (
                        <ChevronDown className="w-5 h-5" />
                      )}
                    </button>
                    
                    <AnimatePresence>
                      {expandedSeasons.includes(season.id) && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.3 }}
                        >
                          <div className="divide-y divide-gray-200 dark:divide-gray-700">
                            {season.episodes.map((episode) => (
                              <div key={episode.id} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                                <div className="flex justify-between items-start mb-2">
                                  <div>
                                    <h4 className="font-semibold">
                                      <span className="text-primary ml-1">قسمت {episode.episodeNumber}:</span> 
                                      {episode.persianTitle}
                                    </h4>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">{episode.title}</p>
                                  </div>
                                  <span className="text-sm bg-gray-200 dark:bg-gray-700 px-2 py-1 rounded">
                                    {episode.duration}
                                  </span>
                                </div>
                                
                                {episode.plot && (
                                  <p className="text-sm mb-3 text-gray-600 dark:text-gray-300">
                                    {episode.plot}
                                  </p>
                                )}
                                
                                <div className="mt-3 space-y-2">
                                  {episode.downloadLinks.map((link) => (
                                    <div 
                                      key={link.id} 
                                      className="flex flex-wrap md:flex-nowrap items-center justify-between p-2 bg-gray-100 dark:bg-gray-700 rounded-lg"
                                    >
                                      <div className="flex items-center mb-2 md:mb-0">
                                        <span className="bg-primary text-white text-xs px-2 py-1 rounded ml-3">
                                          {link.quality}
                                        </span>
                                        <span className="text-xs text-gray-500 dark:text-gray-400">
                                          {link.size}
                                        </span>
                                      </div>
                                      <div className="flex items-center gap-2 w-full md:w-auto">
                                        <a 
                                          href={link.url} 
                                          className="btn-primary text-xs py-1 px-3 flex-1 md:flex-none text-center"
                                        >
                                          دانلود
                                        </a>
                                        <button 
                                          onClick={() => copyToClipboard(link.url, link.id)}
                                          className="btn-secondary text-xs py-1 px-3 flex items-center"
                                        >
                                          <Copy className="w-3 h-3 ml-1" />
                                          {copied === link.id ? 'کپی شد!' : 'کپی لینک'}
                                        </button>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            ))}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="card p-6"
            >
              <h2 className="text-xl font-bold mb-4 flex items-center">
                <MessageSquare className="w-5 h-5 ml-2 text-primary" />
                نظرات کاربران
              </h2>
              <div className="space-y-4">
                {seriesData.comments.map((comment) => (
                  <div key={comment.id} className="border-b border-gray-200 dark:border-gray-700 pb-4 last:border-0">
                    <div className="flex items-center mb-2">
                      <img 
                        src={comment.avatar} 
                        alt={comment.user} 
                        className="w-10 h-10 rounded-full ml-3"
                      />
                      <div>
                        <h4 className="font-semibold">{comment.user}</h4>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{comment.date}</p>
                      </div>
                    </div>
                    <p className="mb-2">{comment.text}</p>
                    <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                      <button className="flex items-center hover:text-primary transition-colors">
                        <Star className="w-4 h-4 ml-1" />
                        {comment.likes} پسندیدم
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="card p-6 mb-8 sticky top-20"
            >
              <h2 className="text-xl font-bold mb-4">سریال‌های مشابه</h2>
              <div className="space-y-4">
                {seriesData.relatedSeries.map((relatedSeries) => (
                  <Link 
                    key={relatedSeries.id} 
                    to={`/series/${relatedSeries.id}`}
                    className="flex items-center p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  >
                    <img 
                      src={relatedSeries.posterUrl} 
                      alt={relatedSeries.title} 
                      className="w-16 h-24 object-cover rounded ml-3"
                    />
                    <div>
                      <h3 className="font-semibold">{relatedSeries.persianTitle}</h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{relatedSeries.title}</p>
                      <p className="text-sm">
                        {relatedSeries.startYear}
                        {relatedSeries.endYear ? ` - ${relatedSeries.endYear}` : ' - تاکنون'}
                      </p>
                    </div>
                  </Link>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SeriesPage;