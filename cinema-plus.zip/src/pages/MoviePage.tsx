import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Play, Download, Copy, Star, Clock, Calendar, Film, User, MessageSquare, Heart } from 'lucide-react';
import { movies } from '../data/movies';
import { Movie } from '../types';
import { useLikedMoviesStore } from '../store/likedMoviesStore';

const MoviePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [movie, setMovie] = useState<Movie | null>(null);
  const [copied, setCopied] = useState<number | null>(null);
  const { likedMovies, toggleLikedMovie } = useLikedMoviesStore();

  useEffect(() => {
    window.scrollTo(0, 0);
    if (id) {
      const foundMovie = movies.find(m => m.id === parseInt(id));
      if (foundMovie) {
        setMovie(foundMovie);
      }
    }
  }, [id]);

  const copyToClipboard = (url: string, linkId: number) => {
    navigator.clipboard.writeText(url);
    setCopied(linkId);
    setTimeout(() => setCopied(null), 2000);
  };

  if (!movie) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  const isLiked = likedMovies.some(m => m.id === movie.id);

  return (
    <div className="pb-24 md:pb-10">
      {/* Hero Section */}
      <div 
        className="relative h-[70vh] bg-cover bg-center"
        style={{ 
          backgroundImage: `linear-gradient(to bottom, rgba(0,0,0,0.7), rgba(0,0,0,0.9)), url(${movie.backdropUrl})` 
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/70 to-transparent"></div>
        <div className="container mx-auto px-4 h-full flex items-end pb-10 relative z-10">
          <div className="flex flex-col md:flex-row items-center md:items-end gap-6 text-white w-full">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="w-32 md:w-48 flex-shrink-0 relative group self-center md:self-auto mr-auto ml-auto md:mr-0"
            >
              <div className="relative overflow-hidden rounded-lg shadow-2xl">
                <img 
                  src={movie.posterUrl} 
                  alt={movie.title} 
                  className="w-full h-auto rounded-lg shadow-lg border-2 border-white/10 transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={() => toggleLikedMovie(movie)}
                className="absolute top-2 right-2 p-2 bg-black/50 rounded-full text-white hover:bg-primary transition-colors duration-300"
              >
                <Heart className={`w-5 h-5 ${isLiked ? 'fill-primary text-primary' : 'text-white'}`} />
              </motion.button>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="flex-1 text-center md:text-right"
            >
              <h1 className="text-2xl md:text-4xl font-bold mb-2 text-white drop-shadow-md">{movie.persianTitle}</h1>
              <h2 className="text-lg md:text-xl text-gray-200 mb-4 drop-shadow-md">{movie.title}</h2>
              
              <div className="flex flex-wrap gap-3 mb-4 justify-center md:justify-start">
                {movie.genres.map((genre, index) => (
                  <span 
                    key={index} 
                    className="px-3 py-1 bg-primary/90 text-white rounded-full text-sm font-medium shadow-md"
                  >
                    {genre}
                  </span>
                ))}
              </div>
              
              <div className="flex flex-wrap gap-4 text-sm md:text-base mb-6 text-white justify-center md:justify-start">
                <div className="flex items-center bg-black/50 px-3 py-1 rounded-full shadow-md">
                  <Star className="w-4 h-4 text-yellow-400 ml-1" />
                  <span>{movie.rating}/10</span>
                </div>
                <div className="flex items-center bg-black/50 px-3 py-1 rounded-full shadow-md">
                  <Clock className="w-4 h-4 text-gray-300 ml-1" />
                  <span>{movie.duration}</span>
                </div>
                <div className="flex items-center bg-black/50 px-3 py-1 rounded-full shadow-md">
                  <Calendar className="w-4 h-4 text-gray-300 ml-1" />
                  <span>{movie.year}</span>
                </div>
              </div>
              
              <div className="flex gap-3 justify-center md:justify-start">
                <motion.a
                  href={movie.trailerUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="btn-primary flex items-center shadow-lg"
                >
                  <Play className="w-4 h-4 ml-2" />
                  پخش تریلر
                </motion.a>
                <motion.a
                  href={movie.downloadLinks[0].url}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-md flex items-center transition-colors shadow-lg"
                >
                  <Download className="w-4 h-4 ml-2" />
                  دانلود
                </motion.a>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Content Section */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="card p-6 mb-8"
            >
              <h2 className="text-xl font-bold mb-4 flex items-center">
                <Film className="w-5 h-5 ml-2 text-primary" />
                خلاصه داستان
              </h2>
              <p className="leading-relaxed">{movie.plot}</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="card p-6 mb-8"
            >
              <h2 className="text-xl font-bold mb-4 flex items-center">
                <User className="w-5 h-5 ml-2 text-primary" />
                عوامل فیلم
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="font-semibold text-gray-500 dark:text-gray-400 mb-1">کارگردان</h3>
                  <p>{movie.director}</p>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-500 dark:text-gray-400 mb-1">بازیگران</h3>
                  <p>{movie.cast.join('، ')}</p>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="card p-6 mb-8"
            >
              <h2 className="text-xl font-bold mb-4 flex items-center">
                <Download className="w-5 h-5 ml-2 text-primary" />
                لینک‌های دانلود
              </h2>
              <div className="space-y-3">
                {movie.downloadLinks.map((link) => (
                  <div 
                    key={link.id} 
                    className="flex flex-wrap md:flex-nowrap items-center justify-between p-3 bg-gray-100 dark:bg-gray-700 rounded-lg"
                  >
                    <div className="flex items-center mb-2 md:mb-0">
                      <span className="bg-primary text-white text-sm px-2 py-1 rounded ml-3">
                        {link.quality}
                      </span>
                      <span className="text-sm text-gray-500 dark:text-gray-400">
                        {link.size}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 w-full md:w-auto">
                      <a 
                        href={link.url} 
                        className="btn-primary text-sm py-2 px-3 flex-1 md:flex-none text-center"
                      >
                        دانلود
                      </a>
                      <button 
                        onClick={() => copyToClipboard(link.url, link.id)}
                        className="btn-secondary text-sm py-2 px-3 flex items-center"
                      >
                        <Copy className="w-4 h-4 ml-1" />
                        {copied === link.id ? 'کپی شد!' : 'کپی لینک'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="card p-6"
            >
              <h2 className="text-xl font-bold mb-4 flex items-center">
                <MessageSquare className="w-5 h-5 ml-2 text-primary" />
                نظرات کاربران
              </h2>
              <div className="space-y-4">
                {movie.comments.map((comment) => (
                  <div key={comment.id} className="border-b border-gray-200 dark:border-gray-700 pb-4 last:border-0">
                    <div className="flex items-center mb-2">
                      <img 
                        src={comment.avatar} 
                        alt={comment.user} 
                        className="w-10 h-10 rounded-full ml-3"
                      />
                      <div>
                        <h4 className="font-semibold">{comment.user}</h4>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{comment.date}</p>
                      </div>
                    </div>
                    <p className="mb-2">{comment.text}</p>
                    <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                      <button className="flex items-center hover:text-primary transition-colors">
                        <Star className="w-4 h-4 ml-1" />
                        {comment.likes} پسندیدم
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="card p-6 mb-8 sticky top-20"
            >
              <h2 className="text-xl font-bold mb-4">فیلم‌های مشابه</h2>
              <div className="space-y-4">
                {movie.relatedMovies.map((relatedMovie) => (
                  <Link 
                    key={relatedMovie.id} 
                    to={`/movie/${relatedMovie.id}`}
                    className="flex items-center p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  >
                    <img 
                      src={relatedMovie.posterUrl} 
                      alt={relatedMovie.title} 
                      className="w-16 h-24 object-cover rounded ml-3"
                    />
                    <div>
                      <h3 className="font-semibold">{relatedMovie.persianTitle}</h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{relatedMovie.title}</p>
                      <p className="text-sm">{relatedMovie.year}</p>
                    </div>
                  </Link>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MoviePage;