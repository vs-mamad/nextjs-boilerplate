import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Film, Tv } from 'lucide-react';
import MovieCard from '../components/MovieCard';
import SeriesCard from '../components/SeriesCard';
import { movies } from '../data/movies';
import { series } from '../data/series';

const HomePage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'movies' | 'series'>('movies');

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { y: 20, opacity: 0 },
    show: { y: 0, opacity: 1 }
  };

  return (
    <div className="pt-20 pb-24 md:pb-10 px-4 md:px-8">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl md:text-3xl font-bold">سینما پلاس</h1>
            <div className="flex bg-gray-100 dark:bg-gray-800 rounded-lg p-1">
              <button
                onClick={() => setActiveTab('movies')}
                className={`flex items-center px-4 py-2 rounded-md transition-colors ${
                  activeTab === 'movies' 
                    ? 'bg-primary text-white' 
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                <Film className="w-4 h-4 ml-2" />
                فیلم‌ها
              </button>
              <button
                onClick={() => setActiveTab('series')}
                className={`flex items-center px-4 py-2 rounded-md transition-colors ${
                  activeTab === 'series' 
                    ? 'bg-primary text-white' 
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                <Tv className="w-4 h-4 ml-2" />
                سریال‌ها
              </button>
            </div>
          </div>
        </motion.div>

        {activeTab === 'movies' && (
          <>
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-xl md:text-2xl font-bold mb-2">فیلم‌های برتر</h2>
              <p className="text-gray-600 dark:text-gray-400 mb-6">مجموعه‌ای از بهترین فیلم‌های جهان</p>
            </motion.div>

            <motion.div
              variants={container}
              initial="hidden"
              animate="show"
              className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6"
            >
              {movies.map((movie) => (
                <motion.div key={movie.id} variants={item}>
                  <MovieCard
                    id={movie.id}
                    title={movie.title}
                    persianTitle={movie.persianTitle}
                    posterUrl={movie.posterUrl}
                    year={movie.year}
                    rating={movie.rating}
                  />
                </motion.div>
              ))}
            </motion.div>
          </>
        )}

        {activeTab === 'series' && (
          <>
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-xl md:text-2xl font-bold mb-2">سریال‌های برتر</h2>
              <p className="text-gray-600 dark:text-gray-400 mb-6">مجموعه‌ای از بهترین سریال‌های جهان</p>
            </motion.div>

            <motion.div
              variants={container}
              initial="hidden"
              animate="show"
              className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6"
            >
              {series.map((serie) => (
                <motion.div key={serie.id} variants={item}>
                  <SeriesCard
                    id={serie.id}
                    title={serie.title}
                    persianTitle={serie.persianTitle}
                    posterUrl={serie.posterUrl}
                    startYear={serie.startYear}
                    endYear={serie.endYear}
                    rating={serie.rating}
                    status={serie.status}
                  />
                </motion.div>
              ))}
            </motion.div>
          </>
        )}
      </div>
    </div>
  );
};

export default HomePage;