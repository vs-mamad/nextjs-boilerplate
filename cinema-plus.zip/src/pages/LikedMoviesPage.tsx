import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Heart, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLikedMoviesStore } from '../store/likedMoviesStore';

const LikedMoviesPage: React.FC = () => {
  const { likedMovies, removeLikedMovie, clearLikedMovies } = useLikedMoviesStore();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { y: 20, opacity: 0 },
    show: { y: 0, opacity: 1 }
  };

  return (
    <div className="pt-20 pb-24 md:pb-10 px-4 md:px-8">
      <div className="container mx-auto">
        <div className="flex justify-between items-center mb-6">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-2xl md:text-3xl font-bold mb-2 flex items-center">
              <Heart className="w-6 h-6 ml-2 text-primary" />
              فیلم‌های مورد علاقه
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              {likedMovies.length > 0 
                ? `${likedMovies.length} فیلم در لیست علاقه‌مندی‌های شما`
                : 'هنوز فیلمی به لیست علاقه‌مندی‌های خود اضافه نکرده‌اید'}
            </p>
          </motion.div>

          {likedMovies.length > 0 && (
            <motion.button
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={clearLikedMovies}
              className="flex items-center bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition-colors"
            >
              <Trash2 className="w-4 h-4 ml-2" />
              حذف همه
            </motion.button>
          )}
        </div>

        {likedMovies.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center py-16 text-center"
          >
            <Heart className="w-16 h-16 text-gray-300 dark:text-gray-600 mb-4" />
            <h2 className="text-xl font-bold mb-2">لیست علاقه‌مندی‌های شما خالی است</h2>
            <p className="text-gray-500 dark:text-gray-400 mb-6">برای افزودن فیلم به این لیست، روی آیکون قلب در صفحه فیلم کلیک کنید</p>
            <Link to="/" className="btn-primary">
              مشاهده فیلم‌ها
            </Link>
          </motion.div>
        ) : (
          <motion.div
            variants={container}
            initial="hidden"
            animate="show"
            className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6"
          >
            {likedMovies.map((movie) => (
              <motion.div 
                key={movie.id} 
                variants={item}
                className="card overflow-hidden group"
              >
                <div className="relative">
                  <img 
                    src={movie.posterUrl} 
                    alt={movie.title} 
                    className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-100 transition-opacity duration-300"></div>
                  
                  <div className="absolute top-2 right-2 flex space-x-2 space-x-reverse">
                    <motion.button
                      whileTap={{ scale: 0.9 }}
                      onClick={() => removeLikedMovie(movie.id)}
                      className="p-2 bg-black/50 rounded-full text-white hover:bg-red-500 transition-colors duration-300"
                    >
                      <Trash2 className="w-5 h-5" />
                    </motion.button>
                  </div>
                  
                  <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
                    <h3 className="text-lg font-bold">{movie.persianTitle}</h3>
                    <p className="text-sm opacity-80">{movie.title}</p>
                    <div className="flex justify-between items-center mt-2">
                      <span className="text-sm">{movie.year}</span>
                      {movie.rating && (
                        <div className="flex items-center bg-black/50 px-2 py-1 rounded-full">
                          <span className="text-sm">{movie.rating}</span>
                        </div>
                      )}
                    </div>
                    
                    <Link 
                      to={`/movie/${movie.id}`}
                      className="mt-3 block w-full text-center bg-primary hover:bg-primary/90 text-white py-2 rounded-md transition-colors"
                    >
                      مشاهده فیلم
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default LikedMoviesPage;